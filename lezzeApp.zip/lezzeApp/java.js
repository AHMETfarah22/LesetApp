// Global Variables
const basket = {};
let discountPercent = 0;
let reviews = [];
let isCartOpen = false;
let isUserMenuOpen = false;

// DOM Elements
const categories = document.querySelectorAll('.category');
const pages = document.querySelectorAll('.page');
const searchInput = document.getElementById('searchInput');
const basketList = document.getElementById('basket-list');
const cartSidebar = document.getElementById('cartSidebar');
const userMenu = document.getElementById('userMenu');
const notification = document.getElementById('notification');
const loadingScreen = document.getElementById('loading-screen');

// Initialize App
document.addEventListener('DOMContentLoaded', function() {
  initializeApp();
  setupEventListeners();
  loadSampleReviews();
  hideLoadingScreen();
});

// Initialize Application
function initializeApp() {
  updateBasketUI();
  updateCartCount();
  renderReviews();
}

// Hide Loading Screen
function hideLoadingScreen() {
  setTimeout(() => {
    if (loadingScreen) {
      loadingScreen.style.opacity = '0';
      setTimeout(() => {
        loadingScreen.style.display = 'none';
      }, 500);
    }
  }, 1000);
}

// Setup Event Listeners
function setupEventListeners() {
  // Category navigation
  categories.forEach((cat) => {
    cat.addEventListener('click', () => {
      switchCategory(cat);
    });
  });

  // Search functionality
  if (searchInput) {
    searchInput.addEventListener('input', filterItems);
    searchInput.addEventListener('keypress', function(e) {
      if (e.key === 'Enter') {
        e.preventDefault();
      }
    });
  }

  // Close menus when clicking outside
  document.addEventListener('click', function(e) {
    if (!e.target.closest('.user-menu') && !e.target.closest('.user-btn')) {
      hideUserMenu();
    }
    if (!e.target.closest('.cart-sidebar') && !e.target.closest('.cart-btn')) {
      if (isCartOpen) {
        toggleCart();
      }
    }
  });

  // Keyboard shortcuts
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
      if (isCartOpen) toggleCart();
      if (isUserMenuOpen) hideUserMenu();
    }
  });
}

// Category Navigation
function switchCategory(selectedCategory) {
  categories.forEach((c) => c.classList.remove('active'));
  selectedCategory.classList.add('active');

  const target = selectedCategory.getAttribute('data-category');
  pages.forEach((page) => {
    page.classList.toggle('active', page.id === target);
  });

  // Clear search when switching categories
  if (searchInput) {
    searchInput.value = '';
  }

  // Add animation
  const activePage = document.querySelector('.page.active');
  if (activePage) {
    activePage.classList.add('fade-in');
    setTimeout(() => {
      activePage.classList.remove('fade-in');
    }, 500);
  }
}

// Search and Filter
function filterItems() {
  const filter = searchInput.value.toLowerCase().trim();
  const activePage = document.querySelector('.page.active');
  
  if (!activePage) return;
  
  const cards = activePage.querySelectorAll('.menu-card');
  let visibleCount = 0;

  cards.forEach((card) => {
    const title = card.querySelector('h3').textContent.toLowerCase();
    const description = card.querySelector('.description')?.textContent.toLowerCase() || '';
    const isVisible = title.includes(filter) || description.includes(filter);
    
    card.style.display = isVisible ? 'block' : 'none';
    if (isVisible) visibleCount++;
  });

  // Show no results message
  showNoResultsMessage(activePage, visibleCount === 0 && filter !== '');
}

function showNoResultsMessage(container, show) {
  let noResultsMsg = container.querySelector('.no-results');
  
  if (show && !noResultsMsg) {
    noResultsMsg = document.createElement('div');
    noResultsMsg.className = 'no-results';
    noResultsMsg.innerHTML = `
      <div style="text-align: center; padding: 2rem; color: var(--text-light);">
        <i class="fas fa-search" style="font-size: 3rem; margin-bottom: 1rem; opacity: 0.5;"></i>
        <p style="font-size: 1.2rem; margin-bottom: 0.5rem;">Aradığınız ürün bulunamadı</p>
        <span>Farklı anahtar kelimeler deneyebilirsiniz</span>
      </div>
    `;
    container.appendChild(noResultsMsg);
  } else if (!show && noResultsMsg) {
    noResultsMsg.remove();
  }
}

function clearSearch() {
  if (searchInput) {
    searchInput.value = '';
    filterItems();
    searchInput.focus();
  }
}

// Basket Operations
function addToBasket(name, price) {
  const stockElem = document.querySelector(`.stock-info[data-stock-for="${name}"]`);
  if (!stockElem) {
    showNotification('Ürün stok bilgisi bulunamadı!', 'error');
    return;
  }

  const currentStock = parseInt(stockElem.textContent.replace('Stok: ', ''), 10);

  if (!basket[name]) {
    basket[name] = { price, count: 0 };
  }

  if (basket[name].count >= currentStock) {
    showNotification('Üzgünüz, stokta yeterli ürün yok.', 'warning');
    return;
  }

  basket[name].count++;
  updateBasketUI();
  updateCartCount();
  updateCartSidebar();
  
  // Update stock display
  const newStock = currentStock - basket[name].count;
  stockElem.textContent = `Stok: ${newStock}`;
  
  // Add visual feedback
  const button = event.target;
  const originalText = button.innerHTML;
  button.innerHTML = '<i class="fas fa-check"></i> Eklendi!';
  button.style.background = 'var(--success-color)';
  
  setTimeout(() => {
    button.innerHTML = originalText;
    button.style.background = '';
  }, 1000);

  showNotification(`${name} sepete eklendi!`, 'success');
}

function removeFromBasket(name) {
  if (basket[name]) {
    const stockElem = document.querySelector(`.stock-info[data-stock-for="${name}"]`);
    if (stockElem) {
      const currentDisplayStock = parseInt(stockElem.textContent.replace('Stok: ', ''), 10);
      stockElem.textContent = `Stok: ${currentDisplayStock + 1}`;
    }

    basket[name].count--;
    if (basket[name].count <= 0) {
      delete basket[name];
    }
    
    updateBasketUI();
    updateCartCount();
    updateCartSidebar();
    showNotification(`${name} sepetten çıkarıldı!`, 'info');
  }
}

function updateBasketUI() {
  if (!basketList) return;

  // Clear existing content
  basketList.innerHTML = '';

  let total = 0;
  const basketItems = Object.entries(basket);

  if (basketItems.length === 0) {
    basketList.innerHTML = `
      <div class="empty-cart">
        <i class="fas fa-shopping-cart"></i>
        <p>Sepetiniz boş</p>
        <span>Lezzetli ürünlerimizi keşfetmek için kategorilere göz atın!</span>
      </div>
    `;
  } else {
    basketItems.forEach(([name, item]) => {
      const itemTotal = item.price * item.count;
      total += itemTotal;

      const basketItem = document.createElement('div');
      basketItem.className = 'basket-item';
      basketItem.innerHTML = `
        <div class="item-info">
          <strong>${name}</strong>
          <span class="item-details">x${item.count} - ${itemTotal.toFixed(2)}₺</span>
        </div>
        <button class="remove-btn" onclick="removeFromBasket('${name}')">
          <i class="fas fa-trash"></i>
        </button>
      `;
      basketList.appendChild(basketItem);
    });
  }

  updateOrderSummary(total);
}

function updateOrderSummary(subtotal) {
  const discountAmount = (subtotal * discountPercent) / 100;
  const total = subtotal - discountAmount;

  // Update summary elements
  const subtotalElem = document.getElementById('subtotal');
  const discountElem = document.getElementById('discount');
  const totalElem = document.getElementById('total');

  if (subtotalElem) subtotalElem.textContent = `${subtotal.toFixed(2)}₺`;
  if (discountElem) discountElem.textContent = `${discountAmount.toFixed(2)}₺`;
  if (totalElem) totalElem.textContent = `${total.toFixed(2)}₺`;

  // Update discount info
  const discountInfo = document.getElementById('discount-info');
  if (discountInfo) {
    if (discountPercent > 0) {
      discountInfo.innerHTML = `
        <i class="fas fa-tag"></i>
        Kupon uygulandı! %${discountPercent} indirim (${discountAmount.toFixed(2)}₺)
      `;
      discountInfo.style.display = 'block';
    } else {
      discountInfo.style.display = 'none';
    }
  }
}

function updateCartCount() {
  const cartCount = document.getElementById('cart-count');
  if (cartCount) {
    const totalItems = Object.values(basket).reduce((sum, item) => sum + item.count, 0);
    cartCount.textContent = totalItems;
    cartCount.style.display = totalItems > 0 ? 'flex' : 'none';
  }
}

// Cart Sidebar
function toggleCart() {
  if (!cartSidebar) return;
  
  isCartOpen = !isCartOpen;
  cartSidebar.classList.toggle('open', isCartOpen);
  
  if (isCartOpen) {
    updateCartSidebar();
    document.body.style.overflow = 'hidden';
  } else {
    document.body.style.overflow = '';
  }
}

function updateCartSidebar() {
  const cartContent = document.getElementById('cartContent');
  const cartTotal = document.getElementById('cartTotal');
  
  if (!cartContent || !cartTotal) return;

  let total = 0;
  const basketItems = Object.entries(basket);

  if (basketItems.length === 0) {
    cartContent.innerHTML = `
      <div class="empty-cart">
        <i class="fas fa-shopping-cart"></i>
        <p>Sepetiniz boş</p>
        <span>Ürün eklemek için kategorilere göz atın!</span>
      </div>
    `;
  } else {
    cartContent.innerHTML = '';
    basketItems.forEach(([name, item]) => {
      const itemTotal = item.price * item.count;
      total += itemTotal;

      const cartItem = document.createElement('div');
      cartItem.className = 'cart-item';
      cartItem.innerHTML = `
        <div class="cart-item-info">
          <h4>${name}</h4>
          <div class="cart-item-details">
            <span class="quantity">x${item.count}</span>
            <span class="price">${itemTotal.toFixed(2)}₺</span>
          </div>
        </div>
        <button class="remove-btn" onclick="removeFromBasket('${name}')">
          <i class="fas fa-times"></i>
        </button>
      `;
      cartContent.appendChild(cartItem);
    });
  }

  const discountAmount = (total * discountPercent) / 100;
  const finalTotal = total - discountAmount;
  cartTotal.textContent = `Toplam: ${finalTotal.toFixed(2)}₺`;
}

function goToCheckout() {
  if (Object.keys(basket).length === 0) {
    showNotification('Sepetinizde ürün bulunmuyor!', 'warning');
    return;
  }
  
  // Switch to payment page
  const paymentCategory = document.querySelector('[data-category="odeme"]');
  if (paymentCategory) {
    switchCategory(paymentCategory);
    toggleCart(); // Close cart sidebar
  }
}

// User Menu
function showUserMenu() {
  if (!userMenu) return;
  
  isUserMenuOpen = !isUserMenuOpen;
  userMenu.classList.toggle('show', isUserMenuOpen);
}

function hideUserMenu() {
  if (userMenu) {
    isUserMenuOpen = false;
    userMenu.classList.remove('show');
  }
}

// Coupon System
function applyCoupon(e) {
  e.preventDefault();
  const code = document.getElementById('coupon-code').value.trim().toUpperCase();
  
  if (!code) {
    showNotification('Lütfen kupon kodu girin.', 'warning');
    return;
  }

  const coupons = {
    LEZZET10: 10,
    INDIRIM20: 20,
    SUPER30: 30,
    YENI15: 15,
    OZEL25: 25
  };

  const previousDiscount = discountPercent;
  discountPercent = coupons[code] || 0;
  
  if (discountPercent > 0) {
    updateBasketUI();
    updateCartSidebar();
    showNotification(`Kupon başarıyla uygulandı! %${discountPercent} indirim kazandınız.`, 'success');
  } else {
    discountPercent = previousDiscount;
    showNotification('Geçersiz kupon kodu.', 'error');
  }
  
  document.getElementById('coupon-code').value = '';
}

// Reviews System
function loadSampleReviews() {
  reviews = [
    {
      name: 'Ahmet Yılmaz',
      text: 'Pizzalar gerçekten çok lezzetli! Hızlı teslimat ve sıcak geldi.',
      rating: 5
    },
    {
      name: 'Ayşe Demir',
      text: 'Burgerler harika, özellikle ABS Burger çok beğendim.',
      rating: 4
    },
    {
      name: 'Mehmet Kaya',
      text: 'Fiyatlar uygun, kalite yüksek. Tavsiye ederim.',
      rating: 5
    }
  ];
  renderReviews();
}

function submitReview(e) {
  e.preventDefault();
  
  const name = document.getElementById('reviewer-name').value.trim();
  const text = document.getElementById('review-text').value.trim();
  const rating = parseInt(document.getElementById('review-rating').value, 10);

  if (!name || !text || !rating) {
    showNotification('Lütfen tüm alanları doldurun.', 'warning');
    return;
  }

  reviews.unshift({ name, text, rating });
  renderReviews();
  e.target.reset();
  showNotification('Yorumunuz başarıyla gönderildi!', 'success');
}

function renderReviews() {
  const reviewList = document.getElementById('review-list');
  if (!reviewList) return;

  if (reviews.length === 0) {
    reviewList.innerHTML = `
      <div style="text-align: center; padding: 2rem; color: var(--text-light);">
        <i class="fas fa-star" style="font-size: 2rem; margin-bottom: 1rem; opacity: 0.5;"></i>
        <p>Henüz yorum yapılmamış</p>
        <span>İlk yorumu siz yapın!</span>
      </div>
    `;
    return;
  }

  reviewList.innerHTML = '';
  reviews.forEach(({ name, text, rating }) => {
    const reviewItem = document.createElement('div');
    reviewItem.className = 'review-item';
    reviewItem.innerHTML = `
      <div class="review-header">
        <strong>${name}</strong>
        <div class="review-rating">
          ${'★'.repeat(rating)}${'☆'.repeat(5 - rating)}
        </div>
      </div>
      <p class="review-text">${text}</p>
    `;
    reviewList.appendChild(reviewItem);
  });
}

// Payment System
function formatCardNumber(input) {
  let value = input.value.replace(/\D/g, '');
  let formatted = value.match(/.{1,4}/g);
  input.value = formatted ? formatted.join(' ').substr(0, 19) : '';
  
  const displayNumber = formatted ? formatted.join(' ') : '•••• •••• •••• ••••';
  const displayElem = document.getElementById('display-card-number');
  if (displayElem) {
    displayElem.textContent = displayNumber;
  }
}

function formatExpiryDate(input) {
  let value = input.value.replace(/\D/g, '');
  if (value.length > 2) {
    value = value.slice(0, 2) + '/' + value.slice(2, 4);
  }
  input.value = value;
  
  const displayElem = document.getElementById('display-card-expiry');
  if (displayElem) {
    displayElem.textContent = value || 'AA/YY';
  }
}

function processPayment(e) {
  e.preventDefault();
  
  if (Object.keys(basket).length === 0) {
    showNotification('Sepetinizde ürün bulunmuyor!', 'warning');
    return;
  }

  const payButton = document.getElementById('payButton');
  const buttonText = payButton.querySelector('span');
  const loadingSpinner = payButton.querySelector('.loading-spinner');

  // Validate form
  const cardNumber = document.getElementById('cardNumber').value.replace(/\s/g, '');
  const cardHolder = document.getElementById('cardHolder').value.trim();
  const expiryDate = document.getElementById('expiryDate').value;
  const cvc = document.getElementById('cvc').value;

  if (cardNumber.length !== 16) {
    showNotification('Lütfen geçerli bir kart numarası girin!', 'error');
    return;
  }

  if (!cardHolder) {
    showNotification('Lütfen kart sahibi adını girin!', 'error');
    return;
  }

  if (!/^(0[1-9]|1[0-2])\/\d{2}$/.test(expiryDate)) {
    showNotification('Geçersiz son kullanma tarihi!', 'error');
    return;
  }

  if (cvc.length !== 3) {
    showNotification('Geçersiz CVC kodu!', 'error');
    return;
  }

  // Show loading state
  payButton.disabled = true;
  buttonText.style.display = 'none';
  loadingSpinner.style.display = 'inline-block';

  // Simulate payment processing
  setTimeout(() => {
    // Reset button
    payButton.disabled = false;
    buttonText.style.display = 'inline';
    loadingSpinner.style.display = 'none';

    // Clear basket and reset form
    Object.keys(basket).forEach(key => delete basket[key]);
    discountPercent = 0;
    updateBasketUI();
    updateCartCount();
    updateCartSidebar();
    
    // Reset form
    document.getElementById('paymentForm').reset();
    document.getElementById('display-card-number').textContent = '•••• •••• •••• ••••';
    document.getElementById('display-card-name').textContent = 'AD SOYAD';
    document.getElementById('display-card-expiry').textContent = 'AA/YY';
    document.getElementById('display-card-cvc').textContent = '•••';

    showNotification('Ödeme başarıyla tamamlandı! Siparişiniz hazırlanıyor.', 'success');
    
    // Switch to pizza page
    setTimeout(() => {
      const pizzaCategory = document.querySelector('[data-category="pizza"]');
      if (pizzaCategory) {
        switchCategory(pizzaCategory);
      }
    }, 2000);
  }, 3000);
}

// Notification System
function showNotification(message, type = 'success') {
  if (!notification) return;

  const notificationText = document.getElementById('notificationText');
  const icon = notification.querySelector('i');
  
  if (notificationText) notificationText.textContent = message;
  
  // Set icon and color based on type
  if (icon) {
    icon.className = type === 'success' ? 'fas fa-check-circle' :
                    type === 'error' ? 'fas fa-exclamation-circle' :
                    type === 'warning' ? 'fas fa-exclamation-triangle' :
                    'fas fa-info-circle';
  }
  
  notification.style.background = type === 'success' ? 'var(--success-color)' :
                                 type === 'error' ? 'var(--danger-color)' :
                                 type === 'warning' ? 'var(--warning-color)' :
                                 'var(--primary-color)';

  notification.classList.add('show');
  
  setTimeout(() => {
    notification.classList.remove('show');
  }, 4000);
}

// Utility Functions
function showOrderHistory() {
  showNotification('Sipariş geçmişi özelliği yakında eklenecek!', 'info');
}

function showSettings() {
  window.location.href = 'ayarlar.html';
}

// Export functions for global access
window.addToBasket = addToBasket;
window.removeFromBasket = removeFromBasket;
window.applyCoupon = applyCoupon;
window.submitReview = submitReview;
window.formatCardNumber = formatCardNumber;
window.formatExpiryDate = formatExpiryDate;
window.processPayment = processPayment;
window.toggleCart = toggleCart;
window.goToCheckout = goToCheckout;
window.showUserMenu = showUserMenu;
window.clearSearch = clearSearch;
window.filterItems = filterItems;
window.showOrderHistory = showOrderHistory;
window.showSettings = showSettings;
