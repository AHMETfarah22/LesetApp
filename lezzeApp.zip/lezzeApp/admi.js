// Login işlemi
document.addEventListener("DOMContentLoaded", () => {
  const loginForm = document.getElementById("login-form");
  const signupForm = document.getElementById("signup-form");

  if (loginForm) {
    loginForm.addEventListener("submit", function (e) {
      e.preventDefault();
      const username = document.getElementById("login-username").value;
      const password = document.getElementById("login-password").value;

      // Demo: Basit kontrol (gerçek veritabanı işlemi yerine)
      if (username === "admin" && password === "1234") {
        window.location.href = "index.html";
      } else {
        alert("Hatalı giriş! Kayıt sayfasına yönlendiriliyorsunuz.");
        setTimeout(() => {
          window.location.href = "signup.html";
        }, 2000);
      }
    });
  }

  // Signup işlemi
  if (signupForm) {
    signupForm.addEventListener("submit", function (e) {
      e.preventDefault();
      const username = document.getElementById("signup-username").value;
      const password = document.getElementById("signup-password").value;

      // Demo kayıt işlemi
      alert("Kayıt başarılı! Giriş sayfasına yönlendiriliyorsunuz.");
      setTimeout(() => {
        window.location.href = "login.html";
      }, 2000);
    });
  }
});

